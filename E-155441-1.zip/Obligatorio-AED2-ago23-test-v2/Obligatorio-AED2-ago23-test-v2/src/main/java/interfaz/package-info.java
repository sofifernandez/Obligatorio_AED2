/**
 * Ninguna de las clase de aquí pueden ser modificadas
 */
package interfaz;